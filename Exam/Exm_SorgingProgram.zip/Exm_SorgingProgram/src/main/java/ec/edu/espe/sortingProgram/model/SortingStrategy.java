/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ec.edu.espe.sortingProgram.model;

/**
 *
 * @author Cristian Acalo, Scriptal, DCCO-ESPE
 */
public interface SortingStrategy {
    public  int[] sort(int data[]);   
}
